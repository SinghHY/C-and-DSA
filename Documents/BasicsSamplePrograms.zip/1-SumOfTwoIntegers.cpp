#include<iostream>
using namespace std;

int main()
{
	//declaring the variables
	int a,b;
	//initializing the variables
	a=5;
	b=6;
	int sum=0;
	sum=a+b;
	//Printing the sum
	cout << sum;
	return 0;
}

